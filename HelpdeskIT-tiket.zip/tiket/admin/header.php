<header id="header" class="page-topbar">
        <!-- start header nav-->
        <div class="navbar-fixed">
            <nav class="cyan">
                <div class="nav-wrapper">
                    <h5 class="logo-wrapper"><a href="index.php" class="brand-logo darken-1"><!-- <img src="images/materialize-logo.png" alt="materialize logo">--> <span class="logo-text">IT Helpdesk <i class="mdi-action-delete"></i> </span>   </a> </h5>
                    <!-- <ul class="right hide-on-med-and-down">
                        <li class="search-out">
                            <input type="text" class="search-out-text">
                        </li>
                        <li>    
                            <a href="javascript:void(0);" class="waves-effect waves-block waves-light show-search"><i class="mdi-action-search"></i></a>                              
                        </li>
                        <li><a href="javascript:void(0);" class="waves-effect waves-block waves-light toggle-fullscreen"><i class="mdi-action-settings-overscan"></i></a>
                        </li>
                    </ul> -->
                </div>
            </nav>
        </div>
        <!-- end header nav-->
    </header>