<footer class="page-footer">
        <div class="footer-copyright">
            <div class="container">
                Copyright &copy; 2017 <a class="grey-text text-lighten-4" href="http://www.hakkoblogs.com" target="_blank">www.hakkoblogs.com</a> All rights reserved.
                <span class="right"> Powered By  <a class="grey-text text-lighten-4" href="http://niqoweb.com/">NiqoWeb</a></span>
            </div>
        </div>
    </footer>